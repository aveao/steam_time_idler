Start the app with Steam_Time_Idler.exe, not steam-idle.exe.

You need to have a public profile.
You need to have steam open.
You need .Net 4.5, try to run it, if it fails, download and install this https://www.microsoft.com/en-us/download/details.aspx?id=30653.

Also developed by ardaozkal, fork it at https://github.com/ardaozkal/steam_time_idler.